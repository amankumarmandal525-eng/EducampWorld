
Educamp World Website

Steps to view the website:

1. Extract the ZIP file.
2. Put your logo image in the folder and name it:
   educamp-logo.png
3. Open the file:
   index.html
4. It will open in Chrome or any browser.

You can upload this website to hosting later to make it live.
